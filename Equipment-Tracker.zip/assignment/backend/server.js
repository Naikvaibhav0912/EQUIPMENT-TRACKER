const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();        // ✅ app is created FIRST
const PORT = 5000;

app.use(cors());
app.use(express.json());

// OPTIONAL root route (safe now)
app.get("/", (req, res) => {
  res.send("Equipment Tracker Backend is running");
});

const DATA_FILE = path.join(__dirname, "data", "equipment.json");

function readData() {
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}

function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// GET all equipment
app.get("/api/equipment", (req, res) => {
  res.json(readData());
});

// ADD equipment
app.post("/api/equipment", (req, res) => {
  const data = readData();
  const newItem = { id: Date.now(), ...req.body };
  data.push(newItem);
  writeData(data);
  res.status(201).json(newItem);
});

// UPDATE equipment
app.put("/api/equipment/:id", (req, res) => {
  const id = Number(req.params.id);
  const data = readData();

  const index = data.findIndex(item => item.id === id);
  if (index === -1) {
    return res.status(404).json({ message: "Not found" });
  }

  data[index] = { ...data[index], ...req.body };
  writeData(data);
  res.json(data[index]);
});

// DELETE equipment
app.delete("/api/equipment/:id", (req, res) => {
  const id = Number(req.params.id);
  const data = readData().filter(item => item.id !== id);
  writeData(data);
  res.json({ message: "Deleted" });
});

app.listen(PORT, () => {
  console.log(`✅ Backend running on http://localhost:${PORT}`);
});