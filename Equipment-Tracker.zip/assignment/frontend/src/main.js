const API = "/api/equipment";

// ✅ EXPLICIT DOM SELECTION (THIS FIXES EVERYTHING)
const form = document.getElementById("equipmentForm");
const nameInput = document.getElementById("name");
const typeInput = document.getElementById("type");
const statusInput = document.getElementById("status");
const lastCleanedInput = document.getElementById("lastCleaned");
const tbody = document.getElementById("tableBody");

let editId = null;

// LOAD DATA
async function loadData() {
  const res = await fetch(API);
  const data = await res.json();

  tbody.innerHTML = "";

  data.forEach(item => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${item.name}</td>
      <td>${item.type}</td>
      <td>${item.status}</td>
      <td>${item.lastCleaned}</td>
      <td>
        <button class="edit-btn">Edit</button>
        <button class="delete-btn">Delete</button>
      </td>
    `;

    tr.querySelector(".edit-btn").addEventListener("click", () => {
      editItem(item);
    });

    tr.querySelector(".delete-btn").addEventListener("click", async () => {
      await fetch(`${API}/${item.id}`, { method: "DELETE" });
      loadData();
    });

    tbody.appendChild(tr);
  });
}

// ADD / UPDATE
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    name: nameInput.value,
    type: typeInput.value,
    status: statusInput.value,
    lastCleaned: lastCleanedInput.value
  };

  if (editId) {
    await fetch(`${API}/${editId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } else {
    await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  }

  editId = null;
  form.reset();
  loadData();
});

// EDIT
function editItem(item) {
  editId = item.id;

  nameInput.value = item.name;
  typeInput.value = item.type;
  statusInput.value = item.status;
  lastCleanedInput.value = item.lastCleaned;
}

// INITIAL LOAD
loadData();
